const MYSQL = {
    host: "localhost",
    port: 3306,
    user: "root",
    password: "",
    database: "testknex",
    debug: false,
}

export {
    MYSQL
}